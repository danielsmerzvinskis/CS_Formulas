﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _2ndTask
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        double speed, time, distance, laiks, garums, atrums; // laiks = time2, garums = distance2, atrums = speed2

        private void label1_Click_1(object sender, EventArgs e)
        {

        }
        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            bool timeInput = double.TryParse(textBox3.Text, out laiks);
            
            if (!timeInput || laiks < 0 || laiks > 9999)
            {
                // MessageBox.Show("Ignorēt šo paziņojumu.");
            }
            // timeInput = float.Parse (textBox3.Text);
            
            
        }   


        private void textBox2_TextChanged2(object sender, EventArgs e)
        {
            
            
            bool cGarumsInput = double.TryParse(textBox2.Text, out garums);

            if (!cGarumsInput || garums < 0 || garums > 999999)
            {
                // MessageBox.Show("Ignorēt šo paziņojumu.");
            }
            

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {
            
            bool speedInput = double.TryParse(textBox1.Text, out atrums);

            if (!speedInput || atrums < 0 || atrums > 9999)
            {
                // MessageBox.Show("Ignorēt šo paziņojumu.");
            
            } 
            
        }
        private void button2_Click(object sender, EventArgs e)
        {
            time = (garums / atrums);
            label4.Text = time.ToString() + " Hrs.";
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            distance = atrums * laiks;
            label4.Text = distance.ToString() + " Km.";
        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            speed = garums / laiks;
            label4.Text = speed.ToString() + " Km/h.";

        }
    }
}
